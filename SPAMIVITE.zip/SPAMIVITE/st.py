#def Login(resp, auth):

#bot = RidenBOT(resp, auth)

#Riden = threading.Thread(target=login, args=('Riden','YOUR TOKEN')).start()

#Riden1 = threading.Thread(target=login, args=('Riden1','YOUR TOKEN')).start()

#Riden2 = threading.Thread(target=login, args=('Riden2','YOUR TOKEN')).start()

#Riden2 = threading.Thread(target=login, args=('Riden3','YOUR TOKEN')).start()


#print("LOGIN SUCCESS RFU")
